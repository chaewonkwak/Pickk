package dalc.hsy.pickk

data class Menu(var menuName:String, var image:String, var desc:String, var calorie:String, var saturatedFat:Int, var protein:Int, var sugars:Int, var caffeine:Int, var color:Int, var cafeName:String) {
}